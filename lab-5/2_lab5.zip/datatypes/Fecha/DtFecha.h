#pragma once

#include <iostream>
#include "../../utils/constant.h"

using namespace std;

class DtFecha
{
private:
    int dia;
    int mes;
    int anio;

public:
    DtFecha();
    DtFecha(int, int, int);
    int getDia();
    int getMes();
    int getAnio();
    bool operator==(const DtFecha &other) const;
    bool operator>(const DtFecha &other) const;
    bool operator>=(const DtFecha &other) const;
    bool operator<=(const DtFecha &other) const;
    friend ostream &operator<<(ostream &, const DtFecha &);
    ~DtFecha();
};