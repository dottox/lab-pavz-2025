#include "DtDireccion.h"

DtDireccion::DtDireccion() {}

DtDireccion::DtDireccion(string calle, string numero, string entreCalles)
{
    this->calle = calle;
    this->numero = numero;
    this->entreCalles = entreCalles;
}

string DtDireccion::getCalle()
{
    return this->calle;
}

string DtDireccion::getNumero()
{
    return this->numero;
}

string DtDireccion::getEntreCalles()
{
    return this->entreCalles;
}

ostream& operator<<(ostream& os, const DtDireccion& dtDireccion)
{
    os << "Calle: " << dtDireccion.calle << endl 
       << "Numero: " << dtDireccion.numero << endl
       << "Entre Calles: " << dtDireccion.entreCalles << endl;
    return os;
}

DtDireccion::~DtDireccion()
{
    // Destructor implementation (if needed)
    // Currently, no dynamic memory allocation is used, so nothing specific to clean up.
}