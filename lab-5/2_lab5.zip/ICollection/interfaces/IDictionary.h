#ifndef IDICTIONARY_H
#define IDICTIONARY_H

#include "IKey.h"
#include "ICollectible.h"
#include "IIterator.h"

class IDictionary
{
public:
    /**
     * Agrega un valor al diccionario
     * @param k la clave, debe ser un objeto creado con new y no se puede reusar.
     *          Se borra al destruir el diccionario
     * @param val el valor a almacenar. No se borra
     */
    virtual void add(IKey *k, ICollectible *val) = 0;

    /**
     * Devuelve true si hay un miembro con cierta clave
     * @param k la clave
     */
    virtual bool member(IKey *k) const = 0;

    /**
     * Saca el miembro del diccionario
     * @param k la clave a buscar
     */
    virtual void remove(IKey *k) = 0;

    /**
     * Saca el miembro del diccionario sin borrarlo
     * @param k la clave a buscar
     */
    virtual void setNull(IKey *k) = 0;

    /**
     * Vacía el diccionario, no se borra ningun objeto
     * @param k la clave a buscar
     */
    virtual void clearDictionary() = 0;

    /**
     * Busca un elemento en el diccionario
     * @param k la clave a buscar
     * @return el ICollectible que se agrego con add o NULL si no hay tal objeto
     */
    virtual ICollectible *find(IKey *k) const = 0;

    /**
     *
     * @return true si el tamano es 0
     */
    virtual bool isEmpty() const = 0;

    /**
     * Devuelve el tamano del diccionario
     * @return
     */
    virtual int getSize() const = 0;

    /**
     * Obtiene un iterador en los elementos del diccionario
     * @return un iterador creado con new
     */
    virtual IIterator *getIterator() = 0;

    virtual ~IDictionary();
};

#endif /* IDICTIONARY_H */
