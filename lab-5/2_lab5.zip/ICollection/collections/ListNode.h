#ifndef LISTNODE_H
#define	LISTNODE_H

#include "../interfaces/ICollection.h"
#include <cstddef>

class ListNode {
public:
    /**
     * Crea un ListNode que almacena un elemento no NULL y su proximo elemento
     * @param elem
     * @param next
     */
    ListNode(ICollectible *elem, ListNode *next = NULL);
    
    // metodos de acceso para elem
    ICollectible *getElem() const;
    void setElem(ICollectible *elem);
    
    // metodos de acceso para next
    ListNode *getNext() const;
    void setNext(ListNode *next);
    
private:
    ICollectible *elem;
    ListNode *next;
};

#endif	/* LISTNODE_H */

